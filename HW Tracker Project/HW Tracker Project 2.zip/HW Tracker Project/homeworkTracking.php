<!-- Creighton Creighton Planner -->
<!-- By: Santiago Lizarraga and Grey Lawson-->
<html>
   <head>
      <meta charset="utf-8">
      <title>Creighton Homework Tracker</title>

      <link href="https://fonts.googleapis.com/css?family=Chilanka&display=swap" rel="stylesheet">
      <link href="style.css" rel="stylesheet" type="text/CSS">
      <script src="homeworkTracking.js"></script>

   </head>
   <body>



</body>
</html>
